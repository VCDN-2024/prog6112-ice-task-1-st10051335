package prog6112.ice.task.pkg1;
import java.util.Scanner;

public class Prog6112IceTask1 {

    public static void main(String[] args) {
        String[] bookTitles = {
            "Harry Potter",
            "The Great Gatsby",
            "To Kill a Mockingbird",
            "Pride and Prejudice",
            "Othello"
        };
        Scanner scanner = new Scanner(System.in);
        System.out.println("Would you like to sort the book titles in ascending (A) or descending (D) order?");
        char sortOrder = scanner.next().charAt(0);
        switch (sortOrder) {
            case 'A':
            case 'a':
                insertionSortAscending(bookTitles);
                System.out.println("Book titles in ascending order:");
                printArray(bookTitles);
                break;
            case 'D':
            case 'd':
                insertionSortDescending(bookTitles);
                System.out.println("Book titles in descending order:");
                printArray(bookTitles);
                break;
            default:
                System.out.println("Invalid input. Please enter A for ascending or D for descending order.");
                break;
        }
    }
    public static void insertionSortAscending(String[] array) {
        int n = array.length;
        for (int i = 1; i < n; i++) {
            String key = array[i];
            int j = i - 1;
            while (j >= 0 && array[j].compareTo(key) > 0) {
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = key;
        }
    }
    public static void insertionSortDescending(String[] array) {
        int n = array.length;
        for (int i = 1; i < n; i++) {
            String key = array[i];
            int j = i - 1;
            while (j >= 0 && array[j].compareTo(key) < 0) {
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = key;
        }
    }
    public static void printArray(String[] array) {
        for (String element : array) {
            System.out.println(element);
            
            System.out.println("Code Attributions"
                    + "Geekforgeeks.com and Wikipedia");
        }
    }   
}
